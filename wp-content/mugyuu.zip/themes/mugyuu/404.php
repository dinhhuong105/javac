<?php if( cf_is_mobile()) : ?>
	<?php get_template_part('404-sp'); ?>
<?php else : ?>
	<?php get_template_part('404-pc'); ?>
<?php endif; ?>
