<?php if( cf_is_mobile()) : ?>
	<?php get_template_part('special-sp'); ?>
<?php else : ?>
	<?php get_template_part('special-pc'); ?>
<?php endif; ?>
