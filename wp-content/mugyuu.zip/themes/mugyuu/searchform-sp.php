<div class="searchArea">
    <form method="get" id="searchform" action="<?php echo home_url('/'); ?>">
        <input type="search" value="" placeholder="検索するキーワードを入力" name="s" id="s">
        <button class="searchIcon"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
</div>
