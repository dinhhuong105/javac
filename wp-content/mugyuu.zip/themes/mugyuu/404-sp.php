<?php get_header(); ?>
<div id="sb-site" class="wrapper error">
    <?php breadcrumb(); ?>
    <section class="errorArea">
        <h1>404<br><span>NOT FOUND</span></h1>
        <p>お探しのページが見つかりません。</p>
    </section>
<?php get_footer(); ?>
