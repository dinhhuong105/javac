<div class="searchArea">
    <form method="get" id="searchform" action="#">
        <input type="search" value="" placeholder="search" name="s" id="s"><button class="searchIcon"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
</div>
