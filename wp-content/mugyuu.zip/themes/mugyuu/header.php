<?php if( cf_is_mobile()) : ?>
	<?php get_template_part('header-sp'); ?>
<?php else : ?>
	<?php get_template_part('header-pc'); ?>
<?php endif; ?>
