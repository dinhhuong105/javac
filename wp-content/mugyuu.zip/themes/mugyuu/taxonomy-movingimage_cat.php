<?php if( cf_is_mobile()) : ?>
	<?php get_template_part('taxonomy-movingimage_cat-sp'); ?>
<?php else : ?>
	<?php get_template_part('taxonomy-movingimage_cat-pc'); ?>
<?php endif; ?>
