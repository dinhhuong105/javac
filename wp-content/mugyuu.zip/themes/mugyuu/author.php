<?php if( cf_is_mobile()) : ?>
	<?php get_template_part('author-sp'); ?>
<?php else : ?>
	<?php get_template_part('author-pc'); ?>
<?php endif; ?>
