<?php get_header(); ?>
<?php breadcrumb(); ?>
	<div class="mainWrap error">
        <div class="mainArea">
            <section class="errorArea">
                <h1><span>404</span><span>Not Found</span></h1>
                <p>お探しのページが見つかりません。</p>
            </section>
        </div>
		<?php get_sidebar(); ?>
    </div>
<?php get_footer(); ?>
