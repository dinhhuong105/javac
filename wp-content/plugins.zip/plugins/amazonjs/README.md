AmazonJS (WordPress Plugin)
========

This repository is in progress and unstable version. Do not install except latest version dose not work.

You can install stable version from: [WordPress.org](http://wordpress.org/plugins/amazonjs/)

## Development

### Requirement

* Grunt
* Compass

### Build css


for debug

```
grunt debug
```

for production

```
grunt
```


### Translation

1. Execute ``grunt update-po``
1. Edit ``languages/amazonjs-*.po``
1. Execute ``grunt update-mo``

## Support

http://wordpress.org/support/plugin/amazonjs
