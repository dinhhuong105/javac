tinyMCE.addI18n('de.aqtwe',{
aqtwe_select_header : 'weitere Formate',
aqtwe_select_error : 'keine Quicktags erkannt'
});

