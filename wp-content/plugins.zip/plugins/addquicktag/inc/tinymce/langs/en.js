tinyMCE.addI18n('en.aqtwe',{
aqtwe_select_header : 'further styles',
aqtwe_select_error : 'no Quicktags found'
});

