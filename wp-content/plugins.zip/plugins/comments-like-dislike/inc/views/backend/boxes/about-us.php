<div class="cld-settings-section" data-settings-ref="about" style="display:none;">
	<h3><?php _e( 'Who we are ?', CLD_TD ); ?></h3>
	<p><?php _e( 'We are WP Happy Coders {:)} ,bunch of <strong>WordPress Developers</strong> with enthusiasm towards <strong>WordPress</strong> trying to spread happiness through WordPress by developing some Handy Wordpress Plugins.', CLD_TD ); ?></p>
	<p><?php _e( 'If you really liked our plugin then please give us a rating from <a href="https://wordpress.org/support/plugin/comments-like-dislike/reviews/#form" target="_blank">here</a>. That\'s the only way to keep us motivated to make the plugin even better.', CLD_TD ); ?></p>
	<h3><?php _e( 'Like us on facebook for latest updates', CLD_TD ); ?></h3>
	<div id="fb-root"></div>
	<script>(function (d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id))
                return;
            js = d.createElement(s);
            js.id = id;
            js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>
	<div class="fb-page" data-href="https://www.facebook.com/wphappycoders" data-width="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/wphappycoders" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/wphappycoders">WP Happy Coders</a></blockquote></div>
</div>