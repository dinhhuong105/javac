<?php
// Silence is golden

